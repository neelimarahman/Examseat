<?php

?>

<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="bootstrap/bootstrap.css">
</head>
<body>
<table class="table table-condensed table-striped">
    <thead>
    <td>Name</td>
    <td>Roll No.</td>
    </thead>
    <tbody>
    <tr>
        <td>Ashish</td>
        <td  onclick="this.parentNode.remove()">61<span class="glyphicon glyphicon-remove"></span></td>
    </tr>
    </tbody>

</table>
<script src="bootstrap/jquery-3.2.0.js"></script>
<script src="bootstrap/bootstrap.js"></script>
</body>
</html>
